module.exports = {
 "verification": "",
 "description": "",
 "domain": "", // This Domain need to be without https:// or http:// (eg: hydrabot.fun not https://hydrabot.fun)
 "google_analitics": "", 
 "token": "",
 "https":"https://",
 "port":"5003",
 "client_id":"",
 "secret":"",
 "support_server_link":"",
 "bot_name":""
}
