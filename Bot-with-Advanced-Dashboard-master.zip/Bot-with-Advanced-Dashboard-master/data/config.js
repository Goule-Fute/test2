module.exports = {
  prefix: "!",
	owners: [""],
}