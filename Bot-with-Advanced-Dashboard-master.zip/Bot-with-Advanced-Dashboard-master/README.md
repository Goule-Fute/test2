# Bot-with-Advanced-Dashboard

## To Start the Bot Go to [My Article Click Here](https://darkthunder.ga/article#/TdgegynB8Ch3W553DyKb/discord-bot-with-advanced-dashboard-code)

## ©️ Credits
This Code is Heavily Modified Version of [Pogy Bot](https://github.com/peterhanania/Pogy-Old)
