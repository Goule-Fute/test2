module.exports = {
  x: "❎",
  fail: "❎ ",
  check: "🔮 ",
  success: "✅ ",
  cash: "$"
}